class Config {
  static const String apiUrl = 'http://143.248.228.49:3000';// 내 노트북 IP
  static const String appKey = '1c1884724b665157347d412727279fcb'; // 네이티브 앱 키
}

